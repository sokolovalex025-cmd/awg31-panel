# NOVA AntiZapret Android

NOVA mobile VPN client MVP 1.1.

### What works
- NOVA mobile UI with server list.
- Import `.conf` and `.ovpn` from Android file picker.
- Profiles persist in app storage between launches.
- **AmneziaWG `.conf` connects through the Android VPNService and the AmneziaWG userspace engine.**
- `.ovpn` opens through a compatible installed OpenVPN client using Android's profile intent.
- Connect/disconnect state for AWG.
- GitHub Actions builds and runs unit tests.

The AmneziaWG tunnel library is Apache-2.0 and exposes the same Go userspace/VpnService architecture used by the upstream Android client. urlAmneziaWG Android sourcehttps://github.com/amnezia-vpn/amneziawg-android

OpenVPN for Android is GPLv2 and explicitly states that it is not a reusable library; NOVA therefore does not copy its UI/engine into this proprietary-style client. `.ovpn` profiles are handed to a compatible OpenVPN app instead. urlOpenVPN for Android license/developer noteshttps://github.com/schwabe/ics-openvpn/blob/master/doc/README.txt

## Build

Use Android Studio or GitHub Actions. The workflow uses JDK 17, Android SDK 36 and Gradle 8.13.

```bash
gradle test assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`
