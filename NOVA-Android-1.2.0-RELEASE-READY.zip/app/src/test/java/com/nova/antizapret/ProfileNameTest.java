package com.nova.antizapret;

import org.junit.Test;
import static org.junit.Assert.*;

public class ProfileNameTest {
    @Test public void createsSafeTunnelNameFromFilename() {
        assertEquals("server_ovpn", ProfileName.tunnelName("server.ovpn"));
        assertEquals("My_Server_01", ProfileName.tunnelName("My Server 01.conf"));
    }

    @Test public void limitsTunnelNameToFifteenCharacters() {
        assertEquals(15, ProfileName.tunnelName("very-long-server-name.conf").length());
    }
}
