package com.nova.antizapret;

import org.junit.Test;
import static org.junit.Assert.*;

public class ConfigImportValidatorTest {
    @Test public void acceptsOvpnAndConfExtensions() {
        assertTrue(ConfigImportValidator.isSupported("server.ovpn"));
        assertTrue(ConfigImportValidator.isSupported("server.conf"));
    }

    @Test public void rejectsUnsupportedExtensions() {
        assertFalse(ConfigImportValidator.isSupported("server.txt"));
        assertFalse(ConfigImportValidator.isSupported("server.apk"));
    }
}
