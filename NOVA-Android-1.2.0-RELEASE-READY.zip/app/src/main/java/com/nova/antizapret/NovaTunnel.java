package com.nova.antizapret;

import org.amnezia.awg.backend.Tunnel;

public final class NovaTunnel implements Tunnel {
    private final String name;
    private volatile State state = State.DOWN;

    public NovaTunnel(String name) { this.name = name; }
    @Override public String getName() { return name; }
    @Override public void onStateChange(State newState) { state = newState; }
    public State getState() { return state; }
}
