package com.nova.antizapret;

import java.util.Locale;

public final class ProfileName {
    private ProfileName() {}

    public static String tunnelName(String filename) {
        String base = filename == null ? "nova" : filename;
        int dot = base.lastIndexOf('.');
        if (dot > 0) base = base.substring(0, dot);
        base = base.replaceAll("[^A-Za-z0-9_=+.-]", "_");
        if (base.isEmpty()) base = "nova";
        if (base.length() > 15) base = base.substring(0, 15);
        return base;
    }

    public static boolean isAwg(String filename) {
        return filename != null && filename.toLowerCase(Locale.ROOT).endsWith(".conf");
    }
}
