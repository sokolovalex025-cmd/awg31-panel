package com.nova.antizapret;

public final class ConfigImportValidator {
    private ConfigImportValidator() {}
    public static boolean isSupported(String name) {
        if (name == null) return false;
        String n = name.toLowerCase(java.util.Locale.ROOT);
        return n.endsWith(".ovpn") || n.endsWith(".conf");
    }
}
