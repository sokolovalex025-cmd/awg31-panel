package com.nova.antizapret;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.VpnService;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import androidx.core.content.FileProvider;

import org.amnezia.awg.backend.GoBackend;
import org.amnezia.awg.backend.Tunnel;
import org.amnezia.awg.config.Config;

import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final int PICK_CONFIG = 42;
    private static final int VPN_PERMISSION = 43;
    private LinearLayout list;
    private TextView status;
    private String selectedPath;
    private String selectedName;
    private GoBackend awgBackend;
    private NovaTunnel activeTunnel;
    private Config pendingConfig;
    private String pendingTunnelName;
    private SharedPreferences prefs;

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    TextView tv(String text,float size){ TextView t=new TextView(this); t.setText(text); t.setTextColor(Color.WHITE); t.setTextSize(size); t.setPadding(dp(12),dp(8),dp(12),dp(8)); return t; }
    GradientDrawable bg(int color,float r){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(r)); return g; }
    Button button(String text){ Button b=new Button(this); b.setText(text); b.setTextColor(Color.BLACK); b.setTextSize(14); b.setAllCaps(false); b.setBackground(bg(Color.rgb(99,245,154),22)); return b; }

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        prefs = getSharedPreferences("nova_profiles", MODE_PRIVATE);
        awgBackend = new GoBackend(getApplicationContext());
        buildUi();
        loadProfiles();
    }

    private void buildUi(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(14),dp(10),dp(14),dp(14)); root.setBackgroundColor(Color.rgb(7,11,18));
        LinearLayout header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo=tv("🛡  NOVA AntiZapret\nFUNTIKAZ",23); logo.setTypeface(null,1); header.addView(logo,new LinearLayout.LayoutParams(0,dp(60),1));
        TextView menu=tv("⚙",25); header.addView(menu,new LinearLayout.LayoutParams(dp(55),dp(60))); root.addView(header);

        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(16),dp(16),dp(16),dp(16)); card.setBackground(bg(Color.rgb(18,25,37),24));
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        TextView power=tv("◉",62); power.setTextColor(Color.rgb(99,245,154)); row.addView(power,new LinearLayout.LayoutParams(dp(90),dp(90)));
        LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); status=tv("Не подключено",19); status.setTypeface(null,1); info.addView(status); info.addView(tv("Выберите сервер и нажмите «Подключить»",12)); row.addView(info,new LinearLayout.LayoutParams(0,dp(90),1)); card.addView(row);
        Button connect=button("🚀  ПОДКЛЮЧИТЬ"); connect.setOnClickListener(v->toggleConnection()); card.addView(connect,new LinearLayout.LayoutParams(-1,dp(54))); root.addView(card,new LinearLayout.LayoutParams(-1,dp(205)));

        LinearLayout title=new LinearLayout(this); title.setGravity(Gravity.CENTER_VERTICAL); TextView st=tv("▣  Серверы",20); st.setTypeface(null,1); title.addView(st,new LinearLayout.LayoutParams(0,dp(60),1)); Button imp=button("＋ Добавить"); imp.setOnClickListener(v->pickConfig()); title.addView(imp,new LinearLayout.LayoutParams(dp(115),dp(45))); root.addView(title);
        list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); ScrollView scroll=new ScrollView(this); scroll.addView(list); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        Button importButton=button("📥  Импорт конфигурации\n    AWG .conf / OpenVPN .ovpn"); importButton.setOnClickListener(v->pickConfig()); LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,dp(64)); ip.setMargins(0,dp(10),0,0); root.addView(importButton,ip);
        setContentView(root);
    }

    private void loadProfiles(){
        Map<String,?> all=prefs.getAll();
        for(String name: all.keySet()) { Object value=all.get(name); if(value instanceof String && new File((String)value).exists()) addServer(name, ProfileName.isAwg(name)?"AmneziaWG":"OpenVPN", "готов"); }
    }

    private void addServer(String name,String proto,String latency){
        TextView s=tv("●  "+name+"\n    "+proto+"                         "+latency,15); s.setTextColor(Color.WHITE); s.setPadding(dp(14),dp(10),dp(14),dp(10)); s.setBackground(bg(Color.rgb(18,25,37),18));
        s.setOnClickListener(v->{ selectedName=name; selectedPath=prefs.getString(name,null); status.setText("Выбран: "+name); });
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(62)); p.setMargins(0,0,0,dp(8)); list.addView(s,p);
    }

    private void pickConfig(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*"); startActivityForResult(i,PICK_CONFIG); }

    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==VPN_PERMISSION && result==RESULT_OK){
            if(pendingConfig!=null) startAwg(pendingTunnelName,pendingConfig);
            return;
        }
        if(request!=PICK_CONFIG||result!=RESULT_OK||data==null)return;
        Uri u=data.getData(); String name=getName(u);
        if(!ConfigImportValidator.isSupported(name)){ Toast.makeText(this,"Поддерживаются только .ovpn и .conf",Toast.LENGTH_LONG).show(); return; }
        try{
            File f=new File(getFilesDir(),"profiles"); if(!f.exists()&&!f.mkdirs()) throw new IOException("Не удалось создать хранилище");
            File outFile=new File(f,safeFileName(name));
            try(InputStream in=getContentResolver().openInputStream(u); OutputStream out=new FileOutputStream(outFile)){ byte[] buf=new byte[8192]; int n; while((n=in.read(buf))!=-1)out.write(buf,0,n); }
            prefs.edit().putString(name,outFile.getAbsolutePath()).apply();
            addServer(name,ProfileName.isAwg(name)?"AmneziaWG":"OpenVPN","готов");
            selectedName=name; selectedPath=outFile.getAbsolutePath(); status.setText("Импортировано: "+name);
            Toast.makeText(this,"Конфигурация добавлена",Toast.LENGTH_SHORT).show();
        }catch(Exception e){ Toast.makeText(this,"Ошибка импорта: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }

    private void toggleConnection(){
        if(activeTunnel!=null && activeTunnel.getState()==Tunnel.State.UP){ stopAwg(); return; }
        if(selectedPath==null){ Toast.makeText(this,"Сначала выберите сервер",Toast.LENGTH_SHORT).show(); return; }
        if(!ProfileName.isAwg(selectedName)){ openOpenVpnProfile(); return; }
        try(InputStream in=new FileInputStream(selectedPath)){
            pendingConfig=Config.parse(in); pendingTunnelName=ProfileName.tunnelName(selectedName);
            Intent prepare=VpnService.prepare(this);
            if(prepare!=null){ startActivityForResult(prepare,VPN_PERMISSION); } else startAwg(pendingTunnelName,pendingConfig);
        }catch(Exception e){ Toast.makeText(this,"Ошибка AWG-конфигурации: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }

    private void startAwg(String name,Config config){
        try{
            activeTunnel=new NovaTunnel(name);
            awgBackend.setState(activeTunnel,Tunnel.State.UP,config);
            status.setText("Подключено • "+selectedName);
            Toast.makeText(this,"AmneziaWG подключён",Toast.LENGTH_SHORT).show();
        }catch(Exception e){ activeTunnel=null; status.setText("Ошибка подключения"); Toast.makeText(this,"Не удалось подключить AWG: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }

    private void stopAwg(){
        try{ awgBackend.setState(activeTunnel,Tunnel.State.DOWN,null); }catch(Exception ignored){}
        activeTunnel=null; status.setText("Не подключено"); Toast.makeText(this,"Соединение отключено",Toast.LENGTH_SHORT).show();
    }

    private void openOpenVpnProfile(){
        try{
            File profile = new File(selectedPath);
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", profile);
            Intent i=new Intent(Intent.ACTION_VIEW,uri);
            i.setType("application/x-openvpn-profile");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(i);
        }catch(Exception e){ Toast.makeText(this,"Для .ovpn установите совместимый OpenVPN-клиент",Toast.LENGTH_LONG).show(); }
    }

    private String getName(Uri u){ String n=null; try(Cursor c=getContentResolver().query(u,null,null,null,null)){ if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(i>=0)n=c.getString(i);}}catch(Exception ignored){} return n==null?"config.conf":n; }
    private String safeFileName(String n){ return n.replaceAll("[^A-Za-z0-9._-]","_"); }
}
